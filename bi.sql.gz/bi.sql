-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2022 at 01:27 PM
-- Server version: 5.7.29-log
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bi`
--

-- --------------------------------------------------------

--
-- Table structure for table `bi`
--

CREATE TABLE `bi` (
  `S.no` int(4) NOT NULL,
  `Blood Group` varchar(10) NOT NULL,
  `First name` varchar(15) NOT NULL,
  `Last name` varchar(15) NOT NULL,
  `Date of Birth` date NOT NULL,
  `Gender` text NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Phone` varchar(12) NOT NULL,
  `City` text NOT NULL,
  `Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verification_code` varchar(255) NOT NULL,
  `is_verified` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bi`
--

INSERT INTO `bi` (`S.no`, `Blood Group`, `First name`, `Last name`, `Date of Birth`, `Gender`, `Email`, `Phone`, `City`, `Date`, `verification_code`, `is_verified`) VALUES
(1, 'B+', 'Prakhar', 'Verma', '2002-08-13', 'Male', 'prakharv385@gmail.com', '95229 20541', 'Bhilai', '2022-08-10 17:08:58', '687b133c7044c916dffd6a5d82c49f07', '1'),
(2, 'O+', 'Vikram', 'Hassan', '2003-05-24', 'Male', 'vermabrother160@gmail.com', '88399 72379', 'Bhilai', '2022-08-12 16:48:37', '32908aac0bbd94dd83368e18cbb869f2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `rd`
--

CREATE TABLE `rd` (
  `S.no` int(4) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Patient name` text NOT NULL,
  `Your name` text NOT NULL,
  `Your email` varchar(30) NOT NULL,
  `phone no` varchar(12) NOT NULL,
  `Blood group` varchar(10) NOT NULL,
  `Unit required` int(3) NOT NULL,
  `City` text NOT NULL,
  `Message` text NOT NULL,
  `verification_code` varchar(255) NOT NULL,
  `is_verified` varchar(10) NOT NULL,
  `Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rd`
--

INSERT INTO `rd` (`S.no`, `Email`, `Patient name`, `Your name`, `Your email`, `phone no`, `Blood group`, `Unit required`, `City`, `Message`, `verification_code`, `is_verified`, `Date`) VALUES
(2, 'prakharv385@gmail.com', 'Ashish', 'Ayush', 'vermabrother160@gmail.com', '88399 72379', 'B+', 1, 'Bhilai', 'Please Help', '17bd34b2262ce491823f659bff1219e5', '0', '2022-08-12 16:21:21'),
(3, 'vermabrother160@gmail.com', 'Tiwari', 'Verma', 'prakharv385@gmail.com', '95229 20541', 'O+', 1, 'Bhilai', 'Please Donate!', '98f7eb521360caae91e64d4a444b828f', '1', '2022-08-12 16:51:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bi`
--
ALTER TABLE `bi`
  ADD PRIMARY KEY (`S.no`);

--
-- Indexes for table `rd`
--
ALTER TABLE `rd`
  ADD PRIMARY KEY (`S.no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bi`
--
ALTER TABLE `bi`
  MODIFY `S.no` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `rd`
--
ALTER TABLE `rd`
  MODIFY `S.no` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
